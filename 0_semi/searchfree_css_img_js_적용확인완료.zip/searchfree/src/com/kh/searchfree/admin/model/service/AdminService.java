package com.kh.searchfree.admin.model.service;

public class AdminService {
	
}
