package com.kh.searchfree.common;

public class ResourcePath {
	public static String path = "http://localhost:8080/searchfree/resources";
}
