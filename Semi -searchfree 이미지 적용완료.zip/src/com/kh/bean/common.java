package com.kh.bean;

public class common {
	public static String url = "http://localhost:8080/searchfree/";
}
